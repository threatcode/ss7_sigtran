#!/bin/bash

pushd src
make
popd
