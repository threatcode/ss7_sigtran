#ifndef _TCAP_EXTERNAL_h
#define _TCAP_EXTERNAL_h

/* This file is added manually to make asn1c output build at all */

#include <ANY.h>

typedef ANY_t EXTERNAL_t;
#define asn_DEF_EXTERNAL asn_DEF_ANY

#endif /* _TCAP_EXTERNAL_h */
