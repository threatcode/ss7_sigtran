#!/bin/bash

pushd src
make clean
popd
